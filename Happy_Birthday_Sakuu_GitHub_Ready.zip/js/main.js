
document.addEventListener("DOMContentLoaded", () => {
  const text = document.querySelector(".typewriter");
  text.style.visibility = "visible";
});
